# KinderCherish Website

Website static sederhana untuk KinderCherish.

## Struktur
- index.html = struktur halaman
- style.css = tampilan website
- script.js = filter umur/curriculum/language + interaksi sederhana
- images/ = tempat menyimpan gambar produk/ilustrasi

## Cara menjalankan
1. Extract ZIP.
2. Buka `index.html` menggunakan browser.
3. Tidak perlu Node.js, React, database, atau build tool.

## Bagian yang perlu diganti
1. Harga worksheet contoh.
2. Link checkout/payment.
3. Link Shopee untuk learning tools.
4. Link WhatsApp.
5. Email.
6. Konten artikel.
7. Gambar produk asli.

## Filter worksheet
Urutan utama:
AGE → CURRICULUM → LANGUAGE → PRODUCT

Data produk saat ini masih contoh dan bisa diedit langsung di `index.html`.

## Catatan
Harga bimbingan Zoom di prototype masih contoh. Ganti dengan harga resmi KinderCherish sebelum dipublikasikan.
